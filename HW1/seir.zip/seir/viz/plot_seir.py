import matplotlib.pyplot as plt
import matplotlib.figure
from typing import Tuple
from numpy.typing import NDArray

def plot_results(infected: NDArray, figsize: Tuple[int, int] = (10, 6), axis_fontsize: int = 16, title_fontsize: int = 20) -> matplotlib.Figure:
    """Plots the time series of infected cases."""
    
    fig, ax = plt.subplots(1, 1, figsize=figsize)
    ax.plot(infected, color='#AA0000', linestyle='dashed', marker='o')
    ax.set_xlabel('Day', fontsize=axis_fontsize)
    ax.set_ylabel('Number of Infected Cases', fontsize=axis_fontsize)
    ax.set_title('Simulated Oubreak', fontsize=title_fontsize)
    ax.grid(alpha=0.2)
    return fig
